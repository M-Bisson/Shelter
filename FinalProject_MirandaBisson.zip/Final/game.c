#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "sound.h"
#include "thunderSound.h"
#include "gameSound.h"
#include "ammoSound.h"
#include "wolfSound.h"
#include "gunSound.h"
#include "playerHitSound.h"
#include "wolfHurtSound.h"
#include "flappingSound.h"
#include "doorSound.h"

// Variables
PLAYER player;
BULLET bullets[BULLETCOUNT];
WEREWOLF wolves[WEREWOLFCOUNT];
int werewolvesKilled;
int activeWolf;
int activeBat;
GUN gun;
HEART lives[HEARTCOUNT];
int ammo;
FLAME flames[FLAMECOUNT];
LIGHTNING lightning;
DOOR door;
CLIP clip[CLIPCOUNT];
BAT bats[BATCOUNT];
int stateBeforeDuck;
int passedGun;
SHIELD shield;

//Sprite states
enum {PLAYERRIGHT, PLAYERLEFT, PLAYERIDLE, TOHELPMATH3, PLAYERGUNRIGHT, PLAYERGUNLEFT};
enum {TOHELPMATH, TOHELPMATH2, WEREWOLFLEFT, WEREWOLFATTACK, WEREWOLFIDLE};
enum {BULLETFLY, BULLETAMMO, BULLETCLIP};
enum {PLACEHOLDER1, PLACEHOLDER2, PLACEHOLDER3, PLACEHOLDER4, BEFOREDUCKRIGHT, BEFOREDUCKLEFT};

//offsets
int hOff = 0;
int vOff = 0;

OBJ_ATTR shadowOAM[128];

// Initialize the game
void initGame() {

	initPlayer();
    initBullets();
	initWerewolves();
	initGun();
	initHearts();
	initFlames();
	initClip();
	initBats();
	initShield();

    // Initialize the number of werewolves killed
	werewolvesKilled = 0;
	activeBat = 0;
	passedGun = 0;
	gun.pickedUp = 0;
	player.hasGun = 0;

	// Initiialize number of bullets when you first pick up gun
	ammo = 3;

}

// Updates the game each frame
void updateGame() {

	updatePlayer();

	// Update all the werewolves
	for (int i = 0; i < WEREWOLFCOUNT; i++)
		updateWerewolf(&wolves[i]);

	// Update all the bullets
	for (int i = 0; i < BULLETCOUNT; i++)
		updateBullet(&bullets[i]);

	// Update all the flames
	for (int i = 0; i < FLAMECOUNT; i++) {
		animateFlame(&flames[i]);
	}

	// Update all the bats
	for (int i = 0; i < BATCOUNT; i++)
		updateBat(&bats[i]);

}

// Draws the game each frame
void drawGame() {

    drawPlayer();

	drawGun();

	// Draw all the enemies
	for (int i = 0; i < WEREWOLFCOUNT; i++)
		drawWerewolf(&wolves[i]);

	// Draw all the bullets
	for (int i = 0; i < BULLETCOUNT; i++)
		drawBullet(&bullets[i]);

	// Draw all the hearts
	for (int i = 0; i < HEARTCOUNT; i++)
		drawHeart(&lives[i]);

	// Draw all the flames
	for (int i = 0; i < FLAMECOUNT; i++)
		drawFlame(&flames[i]);

	// Draw the clip
	for (int i = 0; i < CLIPCOUNT; i++)
		drawClip(&clip[i]);

	// Draw the bats
	for (int i = 0; i < BATCOUNT; i++)
		drawBat(&bats[i]);
}

// Initialize the player
void initPlayer() {

	player.cdel = 2;
	player.height = 64;
	player.width = 32;
	player.aniCounter = 0;
    player.aniState = PLAYERRIGHT;
    player.prevAniState = 0;
    player.curFrame = 0;
    player.numFrames = 3;
	player.lives = 3;
	player.active = 1;
	player.screenCol = 10;
	player.screenRow = 96;
	player.worldRow = player.screenRow + vOff;
    player.worldCol = player.screenCol + hOff;
	player.collide = 0;
	player.attackCount = 0;
	player.hasGun = 0;
	player.cheat = 0;
	player.duck = 0;
}

// Handle every-frame actions of the player
void updatePlayer() {

	if (!BUTTON_HELD(BUTTON_DOWN) && gun.pickedUp && stateBeforeDuck != 0) {
		player.duck = 0;
		player.screenRow = player.worldRow - vOff;
		if (stateBeforeDuck == BEFOREDUCKRIGHT) {
			player.curFrame = 0;
			player.aniState = 4;
			stateBeforeDuck = 0;
		} else if (stateBeforeDuck == BEFOREDUCKLEFT) {
			player.curFrame = 0;
			player.aniState = 5;
			stateBeforeDuck = 0;
		}
	}

	if (player.attackCount >= 8 && !player.cheat) {
		playSoundB(playerHitSound, PLAYERHITSOUNDLEN, PLAYERHITSOUNDFREQ, 0);
		lives[player.lives - 1].active = 0;
		player.lives--;
		player.attackCount = 0;
	}

	//if the player has not passed the gun
	//they can press select to toggle on and off invincible mode
	if (BUTTON_PRESSED(BUTTON_SELECT) && !passedGun) {
		if (player.cheat) {
			player.cheat = 0;
			shield.active = 0;
			drawShield();
		} else {
			player.cheat = 1;
			shield.active = 1;
			drawShield();
		}
	}

	if (BUTTON_PRESSED(BUTTON_B)) {
		//enable pick up of gun
		if (gun.active && collision(player.screenCol, player.screenRow, player.width, player.height, gun.screenCol, gun.screenRow, gun.width, gun.height)) {
			gun.active = 0;
			player.hasGun = 1;
			if (player.aniState == PLAYERIDLE && player.prevAniState == PLAYERLEFT) {
				player.aniState = PLAYERGUNLEFT;
			} else if (player.aniState == PLAYERIDLE && player.prevAniState == PLAYERRIGHT) {
				player.aniState = PLAYERGUNRIGHT;
			} else if (player.aniState == PLAYERLEFT) {
				player.aniState = PLAYERGUNLEFT;
			} else {
				player.aniState = PLAYERGUNRIGHT;
			}
		}
	}

	if (state == ENTER) {
		if (BUTTON_HELD(BUTTON_RIGHT)) {
			if (!collision(player.screenCol, player.screenRow, player.width, player.height, door.screenCol + 27, door.screenRow, door.width, door.height)) {
				player.worldCol += player.cdel;
			}
		}
	} else if (state == EXIT) {
		if (BUTTON_HELD(BUTTON_RIGHT)) {
			if (!collision(player.screenCol, player.screenRow, player.width, player.height, door.screenCol + 27, door.screenRow, door.width, door.height)) {
				player.worldCol += player.cdel;
			}
		}
	} else {
		if (BUTTON_HELD(BUTTON_RIGHT)) {
			for (int i = 0; i < BATCOUNT; i++) {
				if (bats[i].active && collision(player.screenCol, player.screenRow, player.width, player.height, bats[i].screenCol, bats[i].screenRow, bats[i].width, bats[i].height)) {
					player.collide = 1;
				} else {
					player.collide = 0;
				}
			}
			if (!player.collide && wolves[werewolvesKilled].active && collision(player.screenCol, player.screenRow, player.width, player.height, wolves[werewolvesKilled].screenCol, wolves[werewolvesKilled].screenRow, wolves[werewolvesKilled].width, wolves[werewolvesKilled].height)) {
				player.collide = 1;
			} else if (!player.collide) {
				player.collide = 0;
			}
			if (!player.collide) {
				if (!player.duck) {
					player.worldCol += player.cdel;
					hOff += 2;
				} else {
					player.worldCol++;
					hOff++;
				}
			}
		}

		if (BUTTON_HELD(BUTTON_LEFT)) {
			if (player.screenCol - 1 > 0) {
				if (!player.duck) {
					player.worldCol -= player.cdel;
				} else {
					player.worldCol--;
				}
			}
		}

		if (BUTTON_PRESSED(BUTTON_A)) {
			if (player.aniState == PLAYERGUNRIGHT || player.aniState == PLAYERGUNLEFT) {
				fireBullet();
			}
		}

		if (BUTTON_HELD(BUTTON_DOWN) && player.aniState == PLAYERGUNLEFT) {
			player.prevAniState = player.aniState;
			stateBeforeDuck = BEFOREDUCKLEFT;
			player.aniState = 4;
			player.curFrame = 28;
			player.screenRow = 127;
			player.duck = 1;
		} else if (BUTTON_HELD(BUTTON_DOWN) && player.aniState == PLAYERGUNRIGHT) {
			player.prevAniState = player.aniState;
			stateBeforeDuck = BEFOREDUCKRIGHT;
			player.aniState = 1;
			player.curFrame = 28;
			player.screenRow = 127;
			player.duck = 1;
		} 

	}

	player.screenCol = player.worldCol - hOff;

	animatePlayer();

}

// Handle player animation states
void animatePlayer() {

	if (player.duck) {
		// Change the animation frame every 20 frames of gameplay
		if (BUTTON_HELD(BUTTON_LEFT) || BUTTON_HELD(BUTTON_RIGHT)) {
			if(player.aniCounter % 20 == 0) {
				if (player.prevAniState == PLAYERGUNRIGHT) {
					if (player.aniState == 2) {
						player.aniState--;
					} else if (player.aniState == 1) {
						player.aniState++;
					}
				} else if (player.prevAniState == PLAYERGUNLEFT) {
					if (player.aniState == 4) {
						player.aniState--;
					} else if (player.aniState == 3) {
						player.aniState++;
					}
				}

			} 
			player.aniCounter++;
		}
	} else {

		// Set previous state to current state
		player.prevAniState = player.aniState;
		player.aniState = PLAYERIDLE;
		
		// Change the animation frame every 20 frames of gameplay
		if(player.aniCounter % 20 == 0) {
			player.curFrame = (player.curFrame + 1) % player.numFrames;
		}

		// Control movement and change animation state
		if(BUTTON_HELD(BUTTON_LEFT)) {
			//if holding the gun continue holding the gun
			if (player.prevAniState == PLAYERGUNLEFT || player.prevAniState == PLAYERGUNRIGHT) {
				player.aniState = PLAYERGUNLEFT;
			} else {
				player.aniState = PLAYERLEFT;
			}
		}
		if(BUTTON_HELD(BUTTON_RIGHT)) {
			//if holding the gun continue holding the gun
			if (player.prevAniState == PLAYERGUNLEFT || player.prevAniState == PLAYERGUNRIGHT) {
				player.aniState = PLAYERGUNRIGHT;
			} else {
				player.aniState = PLAYERRIGHT;
			}
		}
		// If the player aniState is idle, frame is player standing still
		if (player.aniState == PLAYERIDLE) {
			player.curFrame = 0;
			player.aniCounter = 0;
			player.aniState = player.prevAniState;
		} else {
			player.aniCounter++;
		}
	}
}

// Draw the player
void drawPlayer() {
	if (!player.duck) {
		shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_TALL | ATTR0_NOBLEND;
		shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_LARGE;
		shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(player.aniState * 4, player.curFrame * 8);
	} else {
		shadowOAM[0].attr0 = (ROWMASK & player.screenRow) | ATTR0_SQUARE | ATTR0_NOBLEND;
		shadowOAM[0].attr1 = (COLMASK & player.screenCol) | ATTR1_MEDIUM;
		shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(player.aniState * 4, player.curFrame);
	}
}

// Initialize the pool of bullets
void initBullets() {

	for (int i = 0; i < BULLETCOUNT; i++) {

		bullets[i].screenCol = 0;
		bullets[i].screenRow = 0;
		bullets[i].worldCol = bullets[i].screenCol + hOff;
		bullets[i].worldRow = bullets[i].screenRow + vOff;
		bullets[i].cdel = 3;
		bullets[i].width = 8;
		bullets[i].height = 8;
		bullets[i].aniState = BULLETFLY;
		bullets[i].active = 0;
		bullets[i].oamIndex = i + 18;
		bullets[i].ammo = 0;
	}
}

// Spawn a bullet
void fireBullet() {

	if (ammo > 0) {
		playSoundB(gunSound, GUNSOUNDLEN, GUNSOUNDFREQ, 0);
		// Find the first inactive bullet
		for (int i = 0; i < BULLETCOUNT; i++) {
			if (!bullets[i].active) {

				// Position the new bullet
				bullets[i].worldCol = player.worldCol + player.width - 4;
				bullets[i].worldRow = player.worldRow + player.height/2 - 6;

				// Take the bullet out of the pool
				bullets[i].active = 1;

				// Decrease ammo
				ammo--;
				clip[ammo].active = 0;


				// Break out of the loop
				break;
			}
		}
	}
}

// Handle every-frame actions of a bullet
void updateBullet(BULLET* b) {

	// If active, update; otherwise ignore
	if (b->active) {
		if (!b->ammo) {
			if (b->worldCol < player.worldCol + 220) {
				b->worldCol += b->cdel;
				b->screenCol = b->worldCol - hOff;
				b->screenRow = b->worldRow - vOff;
			} else {
				b->active = 0;
			}
		} else {
			if (BUTTON_PRESSED(BUTTON_B) && collision(player.screenCol, player.screenRow, player.width, player.height, b->screenCol, b->screenRow, b->width, b->height)) {
				playSoundB(ammoSound, AMMOSOUNDLEN, AMMOSOUNDFREQ, 0);
				b->active = 0;
				b->ammo = 0;
				b->aniState = BULLETFLY;
				ammo++;
				clip[ammo - 1].active = 1;

			}
			b->screenRow = b->worldRow - vOff;
			b->screenCol = b->worldCol - hOff;
		}
	}
}

// Draw a bullet
void drawBullet(BULLET* b) {
	if(b->active) {
		if (!b->ammo) {
			shadowOAM[b->oamIndex].attr0 = (ROWMASK & b->screenRow) | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_NOBLEND;
			shadowOAM[b->oamIndex].attr1 = (COLMASK & b->screenCol) | ATTR1_TINY;
			shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(b->aniState, 24);
		} else {
			shadowOAM[b->oamIndex].attr0 = (ROWMASK & b->screenRow) | ATTR0_SQUARE | ATTR0_BLEND;
			shadowOAM[b->oamIndex].attr1 = (COLMASK & b->screenCol) | ATTR1_TINY;
			shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(b->aniState, 24);
		}
	} else {
		shadowOAM[b->oamIndex].attr0 = ATTR0_HIDE;
	}
}

// Initialize the werewolves
void initWerewolves() {

	for (int i = 0; i < WEREWOLFCOUNT; i++){

		wolves[i].cdel = 1;
		wolves[i].width = 32;
		wolves[i].height = 64;
		wolves[i].screenCol = 280;
		wolves[i].screenRow = 96;
		wolves[i].worldRow = wolves[i].screenRow + vOff + 100;
    	wolves[i].worldCol = wolves[i].screenCol + hOff + 100;
		wolves[i].aniCounter = 0;
		wolves[i].aniState = WEREWOLFLEFT;
		wolves[i].prevAniState = 0;
		wolves[i].curFrame = 0;
		wolves[i].numFrames = 3;
		wolves[i].active = 0;
		wolves[i].oamIndex = i + 1;
		wolves[i].attack = 0;
	}
}

// Handle every-frame actions of a werewolf
void updateWerewolf(WEREWOLF* b) {

	//if the player passed the gun and did not pick it up
	//spawn a werewolf to kill them
	if (passedGun) {
		wolves[0].active = 1;
		activeWolf = 1;
	}
	
	//initialize first werewolf
	if (player.hasGun) {
		wolves[0].active = 1;
		activeWolf = 1;
		player.hasGun = 0;
		gun.pickedUp = 1;
	}

	if (b->active) {

		if (collision(player.screenCol, player.screenRow, player.width, player.height, b->screenCol, b->screenRow, b->width, b->height)) {
			//attack
			b->attack = 1;
		} else {
			b->attack = 0;
			b->worldCol -= b->cdel;
		}

		b->screenCol = b->worldCol - hOff;

		// Handle werewolf-bullet collisions
		for (int i = 0; i < BULLETCOUNT; i++) {
			if (bullets[i].active && !bullets[i].ammo && collision(b->screenCol, b->screenRow, b->width, b->height,
				bullets[i].screenCol, bullets[i].screenRow, bullets[i].width, bullets[i].height)) {

				playSoundB(wolfHurtSound, WOLFHURTSOUNDLEN, WOLFSOUNDFREQ, 0);
				// Put werewolf back in the pool
				b->active = 0;
				activeWolf--;

				//drop ammo
				bullets[i].ammo = 1;
				bullets[i].worldCol = b->worldCol;
				bullets[i].worldRow = b->worldRow - 50;
				bullets[i].screenCol = bullets[i].worldCol - hOff;
				bullets[i].screenRow = bullets[i].worldRow - vOff;
				bullets[i].aniState = BULLETAMMO;

				// Update the score
				werewolvesKilled++;
				break;
			} else {
				animateWerewolf(b);
			}
		}
		
	}
	//if no active werewolves activate one
	if (activeWolf == 0 && gun.pickedUp) {
		wolves[werewolvesKilled].active = 1;
		wolves[werewolvesKilled].worldCol = player.worldCol + 240;
		wolves[werewolvesKilled].screenCol = wolves[werewolvesKilled].worldCol - hOff;
		activeWolf = 1;
	}
	// if you have lost a life and there is already one active wolf
	// activate a second wolf to make it more difficult
	if (activeWolf == 1 && (player.lives < 3 || werewolvesKilled > 5) && werewolvesKilled < 14 && gun.pickedUp){ 
		wolves[werewolvesKilled + 1].active = 1;
		wolves[werewolvesKilled + 1].worldCol = player.worldCol + 280;
		wolves[werewolvesKilled + 1].screenCol = wolves[werewolvesKilled].worldCol - hOff;
		activeWolf = 2;
	}
}

//animate the werewolves
void animateWerewolf(WEREWOLF* b) {

    // Set previous state to current state
	if (!b->attack) {
		b->prevAniState = b->aniState;
		b->aniState = WEREWOLFLEFT;
	} else {
		b->prevAniState = b->aniState;
		b->aniState = WEREWOLFATTACK;
	}

    // Change the animation frame every 10 frames of gameplay
    if(b->aniCounter % 20 == 0) {
        b->curFrame = (b->curFrame + 1) % b->numFrames;
		if (b->attack) {
			player.attackCount++;
		}
    }

    b->aniCounter++;
}

// Draw a werewolf
void drawWerewolf(WEREWOLF* l) {

	if(l->active) {
		shadowOAM[l->oamIndex].attr0 = (ROWMASK & l->screenRow) | ATTR0_4BPP | ATTR0_TALL | ATTR0_NOBLEND;
		shadowOAM[l->oamIndex].attr1 = (COLMASK & l->screenCol) | ATTR1_LARGE;
		shadowOAM[l->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(l->aniState * 4, l->curFrame * 8);
	} else {
		shadowOAM[l->oamIndex].attr0 = ATTR0_HIDE;
	}
}

//initialize gun on floor
void initGun() {
	gun.screenRow = 140;
	gun.screenCol = player.screenCol + 40;
	gun.width = 16;
	gun.height = 16;
	gun.active = 1;
	gun.worldCol = gun.screenCol + hOff;
	gun.worldRow = gun.screenRow + vOff;
}

//draw gun on floor
void drawGun() {
	gun.screenCol = gun.worldCol - hOff;
	if (!gun.pickedUp && gun.screenCol + gun.width < 0) {
		gun.active = 0;
		passedGun = 1;
	}
	if(gun.active){
		shadowOAM[17].attr0 = (ROWMASK & gun.screenRow) | ATTR0_SQUARE | ATTR0_BLEND;
		shadowOAM[17].attr1 = (ROWMASK & (gun.screenCol)) | ATTR1_SMALL;
		shadowOAM[17].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 27);
	} else {
		shadowOAM[17].attr0 = ATTR0_HIDE;
	}
}

//initialize the player's lives (hearts)
void initHearts() {
	for (int i = 0; i < HEARTCOUNT; i++) {
		lives[i].width = 8;
		lives[i].height = 8;
		lives[i].screenCol = i * 10;
		lives[i].screenRow = 5;
		lives[i].active = 1;
		lives[i].worldCol = lives[i].screenCol + hOff;
		lives[i].worldRow = lives[i].screenRow + vOff;
		lives[i].oamIndex = i + 21;
	}
}

// //update heart sprites
// void updateHeart(HEART* b) {
// 	// If active, update; otherwise ignore
// 	if (b->active) {
// 		b->worldCol = player.worldCol + ((b->oamIndex - 21) * 10);
// 		b->screenCol = b->worldCol - hOff;
// 	}
// }

//draw heart sprites
void drawHeart(HEART* b) {
	if(b->active == 1) {
		shadowOAM[b->oamIndex].attr0 = (ROWMASK & b->screenRow) | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_NOBLEND;
		shadowOAM[b->oamIndex].attr1 = (COLMASK & b->screenCol) | ATTR1_TINY;
		shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 25);
	} else {
		shadowOAM[b->oamIndex].attr0 = ATTR0_HIDE;
	}
}
 
// Initialize the flames
void initFlames() {
    //flame 0
	flames[0].width = 8;
	flames[0].height = 8;
	flames[0].screenCol = 31;
	flames[0].screenRow = 95;
	flames[0].active = 1;
	flames[0].worldCol = flames[0].screenCol + hOff;
	flames[0].worldRow = flames[0].screenRow + vOff;
	flames[0].oamIndex = 24;
	//flame 1
	flames[1].width = 8;
	flames[1].height = 8;
	flames[1].screenCol = 100;
	flames[1].screenRow = 95;
	flames[1].active = 1;
	flames[1].worldCol = flames[1].screenCol + hOff;
	flames[1].worldRow = flames[1].screenRow + vOff;
	flames[1].oamIndex = 25;

	//flame 2
	flames[2].width = 8;
	flames[2].height = 8;
	flames[2].screenCol = 190;
	flames[2].screenRow = 95;
	flames[2].active = 1;
	flames[2].worldCol = flames[2].screenCol + hOff;
	flames[2].worldRow = flames[2].screenRow + vOff;
	flames[2].oamIndex = 26;

	//flame 3
	flames[3].width = 8;
	flames[3].height = 8;
	flames[3].screenCol = 243;
	flames[3].screenRow = 95;
	flames[3].active = 1;
	flames[3].worldCol = flames[3].screenCol + hOff;
	flames[3].worldRow = flames[3].screenRow + vOff;
	flames[3].oamIndex = 27;

	//flame 4
	flames[4].width = 8;
	flames[4].height = 8;
	flames[4].screenCol = 387;
	flames[4].screenRow = 95;
	flames[4].active = 1;
	flames[4].worldCol = flames[4].screenCol + hOff;
	flames[4].worldRow = flames[4].screenRow + vOff;
	flames[4].oamIndex = 28;

	//flame 5
	flames[5].width = 8;
	flames[5].height = 8;
	flames[5].screenCol = 480;
	flames[5].screenRow = 95;
	flames[5].active = 1;
	flames[5].worldCol = flames[5].screenCol + hOff;
	flames[5].worldRow = flames[5].screenRow + vOff;
	flames[5].oamIndex = 29;

}

// Draw the flames
void drawFlame(FLAME* b) {
	if(b->active == 1) {
		shadowOAM[b->oamIndex].attr0 = (ROWMASK & b->screenRow) | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_NOBLEND;
		shadowOAM[b->oamIndex].attr1 = (COLMASK & b->screenCol) | ATTR1_TINY;
		shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(b->aniState, 26);
	} else {
		shadowOAM[b->oamIndex].attr0 = ATTR0_HIDE;
	}
}

// Animate the flames
void animateFlame(FLAME *b) {
	//update screenCol
    b->screenCol = b->worldCol - hOff;
	// make sure the flame doesn't move with player
	if (BUTTON_HELD(BUTTON_RIGHT)) {
		b->screenCol = b->worldCol - hOff - 2;
	}
	if (BUTTON_HELD(BUTTON_LEFT)) {
		b->screenCol = b->worldCol - hOff + 2;
	}
	b->screenRow = b->worldRow - vOff;

	// Change the animation frame every 10 frames of gameplay
    if(b->aniCounter % 10 == 0) {
        b->aniState = (b->aniState + 1) % 3;
    }
	b->aniCounter++;
}

void initDoor() {
	door.active = 1;
	door.screenCol = 140;
	door.screenRow = 96;
	door.worldCol = door.screenCol + hOff;
	door.worldRow = door.screenRow + vOff;
	door.aniCounter = 0;
	door.aniState = 7;
	door.curFrame = 0;
	door.oamIndex = 31;
	door.height = 64;
	door.width = 32;
	door.open = 0;
}

void drawDoor() {
	if(door.active == 1) {
        shadowOAM[door.oamIndex].attr0 = (ROWMASK & door.screenRow) | ATTR0_4BPP | ATTR0_TALL | ATTR0_NOBLEND;
        shadowOAM[door.oamIndex].attr1 = (COLMASK & door.screenCol) | ATTR1_LARGE;
        shadowOAM[door.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(door.aniState * 4, door.curFrame * 8);
    } else {
        shadowOAM[door.oamIndex].attr0 = ATTR0_HIDE;
    }
}

void updateDoor() {
	door.curFrame++;
	drawDoor();
	waitForVBlank();
	door.curFrame++;
	drawDoor();
	waitForVBlank();
}

//initialize the player's lives (hearts)
void initClip() {
	for (int i = 0; i < CLIPCOUNT; i++) {
		clip[i].width = 8;
		clip[i].height = 8;
		clip[i].screenCol = 30 + (i * 10);
		clip[i].screenRow = 5;
		clip[i].active = 1;
		clip[i].worldCol = clip[i].screenCol + hOff;
		clip[i].worldRow = clip[i].screenRow + vOff;
		clip[i].oamIndex = i + 32;
	}
}

// //update clip sprites
// void updateClip(CLIP* b) {
// 	// update to move with player
// 	b->worldCol = player.worldCol + (30 + ((b->oamIndex - 32) * 10));
// 	b->screenCol = b->worldCol - hOff;
// }

//draw heart sprites
void drawClip(CLIP* b) {
	if(b->active == 1 && gun.pickedUp) {
		shadowOAM[b->oamIndex].attr0 = (ROWMASK & b->screenRow) | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[b->oamIndex].attr1 = (COLMASK & b->screenCol) | ATTR1_TINY;
		shadowOAM[b->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(2, 24);
	} else {
		shadowOAM[b->oamIndex].attr0 = ATTR0_HIDE;
	}
}

// Initialize the bats
void initBats() {

	for (int i = 0; i < BATCOUNT; i++){

		bats[i].cdel = 2;
		bats[i].width = 32;
		bats[i].height = 32;
		bats[i].screenCol = 280;
		bats[i].screenRow = 80;
		bats[i].worldRow = bats[i].screenRow + vOff;
    	bats[i].worldCol = bats[i].screenCol + hOff;
		bats[i].aniCounter = 0;
		bats[i].aniState = 1;
		bats[i].prevAniState = 0;
		bats[i].curFrame = 24;
		bats[i].active = 0;
		bats[i].oamIndex = i + 35;
	}
}

// Draw a bat
void drawBat(BAT* l) {

	if(l->active == 1) {
		shadowOAM[l->oamIndex].attr0 = (ROWMASK & l->screenRow) | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[l->oamIndex].attr1 = (COLMASK & l->screenCol) | ATTR1_MEDIUM;
		shadowOAM[l->oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(l->aniState * 4, l->curFrame);
	} else {
		shadowOAM[l->oamIndex].attr0 = ATTR0_HIDE;
	}
}

// Handle every-frame actions of a bat
void updateBat(BAT* b) {

	if (b->active) {
		if (collision(player.screenCol, player.screenRow, player.width, player.height, b->screenCol, b->screenRow, b->width, b->height)) {
			//attack
			b->attack = 1;
		} else {
			b->attack = 0;
			if (b->screenCol - 1 > 0) {
				b->worldCol -= b->cdel;
			} else {
				b->active = 0;
				activeBat--;
			}
		}

		b->screenCol = b->worldCol - hOff;

		if (b->active) {
			animateBat(b);
		}
		
	}
	//if no active bats activate one
	if (activeBat == 0 && werewolvesKilled > 2) {
		playSoundB(flappingSound, FLAPPINGSOUNDLEN, FLAPPINGSOUNDFREQ, 1);
		for (int i = 0; i < BATCOUNT; i++) {
			if (!bats[i].active) {
				// reset to correct place and values
				bats[i].worldCol = player.worldCol + 240;
				bats[i].screenCol = bats[i].worldCol - hOff;
				bats[i].screenRow = 80;
				bats[i].worldRow = bats[i].screenRow + vOff;
				bats[i].aniCounter = 0;
				bats[i].aniState = 1;
				bats[i].curFrame = 24;
				bats[i].active = 1;
				activeBat++;
			}
			break;
		}
	}
}

//animate the bats
void animateBat(BAT* b) {

    // Change the animation frame every 10 frames of gameplay
    if(b->aniCounter % 5 == 0) {
        b->aniState = ((b->aniState + 1) % 3) + 1;
		if (b->attack) {
			player.attackCount++;
		}
    }

    b->aniCounter++;
}

//draw the shield
void drawShield() {
	if (player.cheat && shield.active) {
		shadowOAM[46].attr0 = (ROWMASK & shield.screenRow) | ATTR0_4BPP | ATTR0_SQUARE;
		shadowOAM[46].attr1 = (COLMASK & shield.screenCol) | ATTR1_MEDIUM;
		shadowOAM[46].attr2 = ATTR2_PALROW(1) | ATTR2_TILEID(20, 25);
	} else {
		shadowOAM[46].attr0 = ATTR0_HIDE;
	}
}

//initialize shield
void initShield() {
	shield.active = 0;
	shield.height = 32;
	shield.width = 32;
	shield.screenCol = 200;
	shield.screenRow = 0;
}