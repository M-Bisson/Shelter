
//{{BLOCK(gameBG1)

//======================================================================
//
//	gameBG1, 512x256@8, 
//	+ palette 256 entries, not compressed
//	+ 235 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 15040 + 4096 = 19648
//
//	Time-stamp: 2019-12-02, 10:35:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_GAMEBG1_H
#define GRIT_GAMEBG1_H

#define gameBG1TilesLen 15040
extern const unsigned short gameBG1Tiles[7520];

#define gameBG1MapLen 4096
extern const unsigned short gameBG1Map[2048];

#define gameBG1PalLen 512
extern const unsigned short gameBG1Pal[256];

#endif // GRIT_GAMEBG1_H

//}}BLOCK(gameBG1)
