// Player Struct
typedef struct {
	int row;
	int col;
    int cdel;
	int width;
    int height;
    int screenCol;
    int screenRow;
    int worldCol;
    int worldRow;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
    int lives;
    int active;
    int collide;
    int attackCount;
    int hasGun;
    int cheat;
    int duck;
} PLAYER;

// Bullet Struct
typedef struct {
	int screenCol;
    int screenRow;
    int worldCol;
    int worldRow;
    int cdel;
	int width;
    int height;
    int aniState;
	int active;
    int oamIndex;
    int ammo;
} BULLET;

// Werewolf Struct
typedef struct {
    int cdel;
	int width;
    int height;
    int screenCol;
    int screenRow;
    int worldCol;
    int worldRow;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int active;
    int oamIndex;
    int attack;
} WEREWOLF;

// Gun struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int active;
    int worldCol;
    int worldRow;
    int pickedUp;
} GUN;

// Heart struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int active;
    int oamIndex;
} HEART;

// Flame struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int active;
    int oamIndex;
    int aniState;
    int aniCounter;
} FLAME;

// Lightning struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int active;
    int curFrame;
    int oamIndex;
    int aniState;
    int aniCounter;
    int numFrames;
} LIGHTNING;

// Clip struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int active;
    int oamIndex;
} CLIP;

// Door struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int active;
    int curFrame;
    int oamIndex;
    int aniState;
    int aniCounter;
    int numFrames;
    int open;
} DOOR;

// Bat Struct
typedef struct {
    int cdel;
	int width;
    int height;
    int screenCol;
    int screenRow;
    int worldCol;
    int worldRow;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int active;
    int oamIndex;
    int attack;
} BAT;

// Arrow struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int worldRow;
    int worldCol;
    int active;
    int oamIndex;
    int aniState;
    int aniCounter;
} ARROW;

// Gun struct
typedef struct {
    int width;
    int height;
    int screenRow;
    int screenCol;
    int active;
    int worldCol;
    int worldRow;
} SHIELD;

// Constants
#define BULLETCOUNT 3
#define WEREWOLFCOUNT 15
#define HEARTCOUNT 3
#define FLAMECOUNT 6
#define CLIPCOUNT 3
#define BATCOUNT 10

// Variables
extern PLAYER player;
extern BULLET bullets[BULLETCOUNT];
extern WEREWOLF werewolves[WEREWOLFCOUNT];
extern int werewolvesKilled;
extern HEART lives[HEARTCOUNT];
extern int hOff;
extern int vOff;
extern FLAME flames[FLAMECOUNT];
extern LIGHTNING lightning;
extern DOOR door;
extern int doorWaitCount;
extern CLIP clip[CLIPCOUNT];
extern BAT bats[BATCOUNT];
extern int activeWolf;
extern int activeBat;
extern ARROW arrow;
extern SHIELD shield;

// states
enum {START, GAME, PAUSE, WIN, LOSE, INSTRUCTIONS, ENTER, EXIT};
extern int state;

// Prototypes
void initGame();
void updateGame();
void drawGame();

// Player
void initPlayer();
void updatePlayer();
void drawPlayer();
void animatePlayer();

// Bullets
void initBullets();
void fireBullet();
void updateBullet(BULLET *);
void drawBullet(BULLET *);

// Werewolves
void initWerewolves();
void updateWerewolf(WEREWOLF *);
void drawWerewolf(WEREWOLF *);
void animateWerewolf(WEREWOLF *);

// Gun
void initGun();
void drawGun();
void updateGun();

// Hearts
void initHearts();
void drawHeart(HEART *);
void updateHeart(HEART *);

// Clip
void initClip();
void drawClip(CLIP *);
void updateClip(CLIP *);

// Flame
void initFlames();
void drawFlame(FLAME *);
void animateFlame(FLAME *);

// Door
void initDoor();
void drawDoor();
void updateDoor();

// Bat
void initBats();
void drawBat(BAT *);
void updateBat(BAT *);
void animateBat(BAT *);

// Shield
void initShield();
void drawShield();