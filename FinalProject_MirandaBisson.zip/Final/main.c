#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "text.h"
#include "game.h"
#include "gameBG.h"
#include "gameBG1.h"
#include "start.h"
#include "sound.h"
#include "loseBG.h"
#include "winBG.h"
#include "instructionsBG.h"
#include "pauseBG.h"
#include "spritesheet.h"
#include "entranceBG.h"
#include "thunderSound.h"
#include "gameSound.h"
#include "ammoSound.h"
#include "wolfSound.h"
#include "gunSound.h"
#include "playerHitSound.h"
#include "wolfHurtSound.h"
#include "flappingSound.h"
#include "doorSound.h"

/* CHEAT: While in-game, press backspace to toggle invincibility */

// Prototypes
void initialize();
void initArrow();
void drawArrow();
void animateArrow();

// State Prototypes
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();
void instructions();
void goToInstructions();
void goToEnter();
void enter();
void goToExit();
void exitScene();

// States
int state;
int prevState;

// Button Variables
unsigned int buttons;
unsigned int oldButtons;

// Random Seed
int seed;

// Variables
ARROW arrow;
SOUND soundA;
SOUND soundB;
int blendValue = 0;
int max = 0;

// Text Buffer
char buffer[41];

// Shadow OAM
OBJ_ATTR shadowOAM[128];

// variables
int doorWaitCount = 0;

int main() {

    initialize();

    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;

        // State Machine
        switch(state) {

            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
            case INSTRUCTIONS:
                instructions();
                break;
            case ENTER:
                enter();
                break;
            case EXIT:
                exitScene();
                break;
        }

    }
}

// Sets up GBA
void initialize() {

    //load palette and tiles
	DMANow(3, spritesheetPal, SPRITEPALETTE, 256);
	DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2 );

    hideSprites();

    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
    
	lightning.screenRow = 0;
	lightning.screenCol = 200;
    lightning.aniCounter = 0;
    lightning.aniState = 6;
    lightning.curFrame = 0;
    lightning.active = 1;
    lightning.height = 64;
    lightning.width = 32;
    lightning.numFrames = 4;

    //set up sound
    setupSounds();
	setupInterrupts();

    // Set up the first state
    goToStart();
}

// Sets up the start state
void goToStart() {

    hOff = 0;

    hideSprites();
    initArrow();
    doorWaitCount = 0;
    lightning.screenRow = 0;
	lightning.screenCol = 200;
    lightning.active = 1;
        
    //DMA to load start image pallet
    DMANow(3, &startPal, PALETTE, 256);

    DMANow(3, startMap, &SCREENBLOCK[22], 1024 * 2);
    DMANow(3, startTiles, &CHARBLOCK[0], startTilesLen / 2);
    REG_BG0CNT = BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(22) | BG_8BPP;

    playSoundA(thunderSound,THUNDERSOUNDLEN,THUNDERSOUNDFREQ, 1);


    state = START;

}

// Runs every frame of the start state
void start() {

    animateArrow();
    drawArrow();

    if(lightning.aniCounter % 20 == 0) {
        lightning.curFrame = (lightning.curFrame + 1) % lightning.numFrames;
    }
    lightning.aniCounter++;

    if(lightning.active == 1) {
        shadowOAM[30].attr0 = (ROWMASK & lightning.screenRow) | ATTR0_4BPP | ATTR0_TALL;
        shadowOAM[30].attr1 = (COLMASK & lightning.screenCol) | ATTR1_LARGE;
        shadowOAM[30].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(lightning.aniState * 4, lightning.curFrame * 8);
    } else {
        shadowOAM[30].attr0 = ATTR0_HIDE;
    }

    if (BUTTON_PRESSED(BUTTON_DOWN) && arrow.screenRow + 22 < 131) {
        arrow.screenRow += 22;
    }
    if (BUTTON_PRESSED(BUTTON_UP) && arrow.screenRow - 22 > 107) {
        arrow.screenRow -= 22;
    }

    waitForVBlank();

	//Copy the shadowOAM into the OAM
	DMANow(3, shadowOAM, OAM, 128* 4);

    // State transitions
    if (BUTTON_PRESSED(BUTTON_START) && arrow.screenRow == 108) {
        prevState = state;
        goToEnter();
    } else if (BUTTON_PRESSED(BUTTON_START) && arrow.screenRow == 130) {
        prevState = state;
        goToInstructions();
    }
}

void goToEnter() {

    hOff = 0;

    hideSprites();
    lightning.screenRow = 0;
	lightning.screenCol = 50;

    initPlayer();
    initDoor();
        
    //DMA to load start image pallet
    DMANow(3, &entranceBGPal, PALETTE, 256);

    DMANow(3, entranceBGMap, &SCREENBLOCK[12], 1024 * 2);
    DMANow(3, entranceBGTiles, &CHARBLOCK[0], entranceBGTilesLen / 2);
    REG_BG0CNT = BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(12) | BG_8BPP;

    state = ENTER;
}

void enter() {
    
    if(lightning.aniCounter % 20 == 0) {
        lightning.curFrame = (lightning.curFrame + 1) % lightning.numFrames;
    }
    lightning.aniCounter++;

    if(lightning.active == 1) {
        shadowOAM[30].attr0 = (ROWMASK & lightning.screenRow) | ATTR0_4BPP | ATTR0_TALL;
        shadowOAM[30].attr1 = (COLMASK & lightning.screenCol) | ATTR1_LARGE;
        shadowOAM[30].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(lightning.aniState * 4, lightning.curFrame * 8);
    } else {
        shadowOAM[30].attr0 = ATTR0_HIDE;
    }

    updatePlayer();
    drawPlayer();
    drawDoor();

    waitForVBlank();

	//Copy the shadowOAM into the OAM
	DMANow(3, shadowOAM, OAM, 128* 4);

    // State transitions
    if (BUTTON_PRESSED(BUTTON_B) && collision(player.screenCol, player.screenRow, player.width, player.height, door.screenCol, door.screenRow, door.width, door.height)) {
        playSoundB(doorSound, DOORSOUNDLEN, DOORSOUNDFREQ, 0);
        updateDoor();
        door.open = 1;
    } else if (BUTTON_PRESSED(BUTTON_START)) {
        prevState = state;
        goToStart();
    }
    
    if (door.open) {
        doorWaitCount++;
        if (doorWaitCount > 20) {
            prevState = state;
            goToGame();
        }
    }

}

// Sets up the game state
void goToGame() {
    lightning.active = 0;
    arrow.active = 0;
    shadowOAM[30].attr0 = ATTR0_HIDE;
    
    //set alpha blending registers for white
    REG_BLDCNT = BLD_BDa | BLD_STD | BLD_BG0b | BLD_BG1b;    

    hideSprites();

    playSoundA(gameSound, GAMESOUNDLEN, GAMESOUNDFREQ, 1);

    DMANow(3, gameBGPal, PALETTE, 256);

    //set up backgrounds for mode 0
    DMANow(3, gameBGMap, &SCREENBLOCK[30], gameBGMapLen / 2);
    DMANow(3, gameBG1Map, &SCREENBLOCK[28], gameBG1MapLen / 2);
    DMANow(3, gameBG1Tiles, &CHARBLOCK[2], gameBG1TilesLen / 2);
    DMANow(3, gameBGTiles, &CHARBLOCK[0], gameBGTilesLen / 2);

    REG_BG1CNT = BG_SIZE_WIDE | BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_8BPP;
    REG_BG0CNT = BG_SIZE_WIDE | BG_CHARBLOCK(0) | BG_SCREENBLOCK(30) | BG_8BPP;

    REG_BG0HOFF = hOff;
    REG_BG1HOFF = hOff;

    initGame();

    state = GAME;
}

// Runs every frame of the game state
void game() {

    updateGame();

    //change weight of alpha blend so it fades
    if (blendValue - 1 >= 0 && max) {
        blendValue--;
        if (blendValue == 0) {
            max = 0;
        }
    } else if (blendValue + 1 <= 17 && !max) {
        blendValue++;
        if (blendValue == 17) {
            max = 1;
        }
    }
    REG_BLDALPHA = BLD_EVB(blendValue) | BLD_EVA(17);
    
	REG_BG0HOFF = hOff;
    REG_BG0VOFF = vOff;
    REG_BG1HOFF = hOff / 2;
    drawGame();

    waitForVBlank();
    
	//Copy the shadowOAM into the OAM
	DMANow(3, shadowOAM, OAM, 128 * 4);

    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)) {
        prevState = state;
        goToPause();
    } else if (werewolvesKilled == WEREWOLFCOUNT){
        for (int i = 0; i < HEARTCOUNT; i++) {
        lives[i].active = 0;
        }
        for (int i = 0; i < CLIPCOUNT; i++) {
            clip[i].active = 0;
        }
        drawGame();
        prevState = state;
        goToExit();
    } else if (player.lives == 0) {
        prevState = state;
        goToLose();
    }
}

// Sets up the pause state
void goToPause() {

    REG_BG0HOFF = 0;

    initArrow();
    arrow.screenRow = 40;
    arrow.screenCol -= 4;

    playSoundB(wolfSound, WOLFSOUNDLEN, WOLFSOUNDFREQ, 0);
    playSoundA(thunderSound, THUNDERSOUNDLEN, THUNDERSOUNDFREQ, 1);

    hideSprites();

    DMANow(3, pauseBGPal, PALETTE, 256);

    DMANow(3, pauseBGMap, &SCREENBLOCK[20], 1024 * 2);

    DMANow(3, pauseBGTiles, &CHARBLOCK[0], pauseBGTilesLen / 2);

    REG_BG0CNT = BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(20) | BG_8BPP;

    state = PAUSE;
}

// Runs every frame of the pause state
void pause() {

    animateArrow();
    drawArrow();

    waitForVBlank();

    //Copy the shadowOAM into the OAM
	DMANow(3, shadowOAM, OAM, 128* 4);

    if(BUTTON_PRESSED(BUTTON_DOWN) && arrow.screenRow + 35 < 111) {
        arrow.screenRow += 35;
    }
    if(BUTTON_PRESSED(BUTTON_UP) && arrow.screenRow - 35 > 39) {
        arrow.screenRow -= 35;
    }

    // State transitions
    if (BUTTON_PRESSED(BUTTON_START) && arrow.screenRow == 40) {
        prevState = state;
        goToGame();
    } else if (BUTTON_PRESSED(BUTTON_START) && arrow.screenRow == 75) {
        prevState = state;
        goToStart();
    } else if (BUTTON_PRESSED(BUTTON_START) && arrow.screenRow == 110) {
        prevState = state;
        goToInstructions();
    }
}

void goToExit() {
    hideSprites();
    doorWaitCount = 0;
    initDoor();
    door.worldCol = hOff + 209;
    door.screenCol = door.worldCol - hOff;
    state = EXIT;
}

void exitScene() {

    updatePlayer();
    drawPlayer();
    drawDoor();

    waitForVBlank();

	//Copy the shadowOAM into the OAM
	DMANow(3, shadowOAM, OAM, 128* 4);

    // State transitions
    if (BUTTON_PRESSED(BUTTON_B) && collision(player.screenCol, player.screenRow, player.width, player.height, door.screenCol, door.screenRow, door.width, door.height)) {
        playSoundB(doorSound, DOORSOUNDLEN, DOORSOUNDFREQ, 0);
        updateDoor();
        door.open = 1;
    } else if (BUTTON_PRESSED(BUTTON_START)) {
        prevState = state;
        goToPause();
    }
    
    if (door.open) {
        doorWaitCount++;
        if (doorWaitCount > 20) {
            prevState = state;
            goToWin();
        }
    }
}

// Sets up the win state
void goToWin() {
    REG_BG0HOFF = 0;

    playSoundA(wolfSound, WOLFSOUNDLEN, WOLFSOUNDFREQ, 0);

    hideSprites();

    //DMA to load win image pallet
    DMANow(3, &winBGPal, PALETTE, 256);

    DMANow(3, winBGMap, &SCREENBLOCK[18], 1024 * 2);
    DMANow(3, winBGTiles, &CHARBLOCK[0], winBGTilesLen / 2);
    REG_BG0CNT = BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(18) | BG_8BPP;

    waitForVBlank();

    state = WIN;
}

// Runs every frame of the win state
void win() {

    waitForVBlank();

    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)) {
        prevState = state;
        goToStart();
    }
}

// Sets up the lose state
void goToLose() {

    REG_BG0HOFF = 0;

    playSoundA(wolfSound, WOLFSOUNDLEN, WOLFSOUNDFREQ, 0);

    hideSprites();

    //DMA to load win image pallet
    DMANow(3, &loseBGPal, PALETTE, 256);

    DMANow(3, loseBGMap, &SCREENBLOCK[16], 1024 * 2);
    DMANow(3, loseBGTiles, &CHARBLOCK[0], loseBGTilesLen / 2);
    REG_BG0CNT = BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(16) | BG_8BPP;

    waitForVBlank();

    state = LOSE;
}

// Runs every frame of the lose state
void lose() {

    waitForVBlank();

    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)) {
        prevState = state;       
        goToStart();
    }
}

void goToInstructions() {

    hideSprites();

    pauseSound();

    //DMA to load win image pallet
    DMANow(3, &instructionsBGPal, PALETTE, 256);

    DMANow(3, instructionsBGMap, &SCREENBLOCK[14], 1024 * 2);
    DMANow(3, instructionsBGTiles, &CHARBLOCK[0], instructionsBGTilesLen / 2);
    REG_BG0CNT = BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(14) | BG_8BPP;

    waitForVBlank();

    state = INSTRUCTIONS;
}

void instructions() {

    waitForVBlank();
    
    if(BUTTON_PRESSED(BUTTON_START) && prevState == PAUSE) {
        prevState = state;
        goToPause();
    } else if (BUTTON_PRESSED(BUTTON_START) && prevState == START) {
        prevState = state;
        goToStart();
    }
}

void initArrow() {
    arrow.active = 1;
    arrow.aniState = 0;
    arrow.aniCounter = 0;
    arrow.oamIndex = 45;
    arrow.screenCol = 117;
    arrow.screenRow = 108;
    arrow.width = 8;
    arrow.height = 8;
}

void drawArrow() {
    if (arrow.active) {
        shadowOAM[arrow.oamIndex].attr0 = (ROWMASK & arrow.screenRow) | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_NOBLEND;
        shadowOAM[arrow.oamIndex].attr1 = (COLMASK & arrow.screenCol) | ATTR1_TINY;
        shadowOAM[arrow.oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(arrow.aniState, 29);
    } else {
        shadowOAM[arrow.oamIndex].attr0 = ATTR0_HIDE;
    }
}

void animateArrow() {
    // Change the animation frame every 10 frames of gameplay
    if(arrow.aniCounter % 20 == 0) {
        arrow.aniState = (arrow.aniState + 1) % 2;
    }
	arrow.aniCounter++;
}