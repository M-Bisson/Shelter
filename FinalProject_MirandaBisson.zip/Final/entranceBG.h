
//{{BLOCK(entranceBG)

//======================================================================
//
//	entranceBG, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ 138 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 8832 + 2048 = 11392
//
//	Time-stamp: 2019-11-10, 10:25:27
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ENTRANCEBG_H
#define GRIT_ENTRANCEBG_H

#define entranceBGTilesLen 8832
extern const unsigned short entranceBGTiles[4416];

#define entranceBGMapLen 2048
extern const unsigned short entranceBGMap[1024];

#define entranceBGPalLen 512
extern const unsigned short entranceBGPal[256];

#endif // GRIT_ENTRANCEBG_H

//}}BLOCK(entranceBG)
