
//{{BLOCK(loseBG)

//======================================================================
//
//	loseBG, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ 172 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 11008 + 2048 = 13568
//
//	Time-stamp: 2019-11-12, 13:39:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LOSEBG_H
#define GRIT_LOSEBG_H

#define loseBGTilesLen 11008
extern const unsigned short loseBGTiles[5504];

#define loseBGMapLen 2048
extern const unsigned short loseBGMap[1024];

#define loseBGPalLen 512
extern const unsigned short loseBGPal[256];

#endif // GRIT_LOSEBG_H

//}}BLOCK(loseBG)
